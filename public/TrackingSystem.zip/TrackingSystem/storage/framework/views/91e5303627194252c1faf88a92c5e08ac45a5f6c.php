<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <title>Tracking System</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link href='https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900|Material+Icons' rel="stylesheet">
</head>
<body>
    <div id="app">
        <?php if(auth()->guard()->check()): ?>
            <sidepanel-component></sidepanel-component>
        <?php else: ?>
            <home-component></home-component>
        <?php endif; ?>
    </div>
</body>

<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

</html><?php /**PATH C:\Users\VYD-ASUS ROG\Documents\GitHub\TrackingSystem\resources\views//home/userlogin.blade.php ENDPATH**/ ?>